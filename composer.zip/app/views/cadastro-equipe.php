<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Equipe - FutPlay</title>
    <meta name="description" content="Cadastre sua equipe de futebol amador na plataforma FutPlay">

    <!-- Bootstrap 5.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?= BASE_URL ?>/public/assets/css/style.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/public/assets/css/cadastro.css">
</head>

<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-custom fixed-top">
        <div class="container">
            <a class="navbar-brand fw-bold fs-3" href="<?= BASE_URL ?>/inicio">
                <i class="bi bi-trophy-fill me-2"></i>FutPlay
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?= BASE_URL ?>/inicio">Voltar ao Início</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="main-content">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8 col-xl-6">
                    <div class="form-container">
                        <!-- Header -->
                        <div class="text-center mb-5">
                            <div
                                class="form-icon bg-custom text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-4">
                                <i class="bi bi-people-fill fs-2"></i>
                            </div>
                            <h1 class="display-6 fw-bold text-dark mb-3">Cadastro de Equipe</h1>
                            <p class="lead text-muted">
                                Preencha os dados da sua equipe para começar a usar o FutPlay
                            </p>
                        </div>

                        <!-- Form -->
                        <form id="cadastroEquipeForm" class="needs-validation" novalidate>
                            <div class="row g-4">
                                <!-- Nome da Equipe -->
                                <div class="col-12">
                                    <label for="nomeEquipe" class="form-label fw-semibold">
                                        <i class="bi bi-trophy me-2 text-success"></i>Nome da Equipe *
                                    </label>
                                    <input type="text" class="form-control form-control-lg" id="nomeEquipe"
                                        name="nomeEquipe" required>
                                    <div class="invalid-feedback">
                                        Por favor, informe o nome da equipe.
                                    </div>
                                </div>

                                <!-- Logradouro -->
                                <div class="col-12">
                                    <label for="logradouro" class="form-label fw-semibold">
                                        <i class="bi bi-geo-alt me-2 text-success"></i>Logradouro *
                                    </label>
                                    <input type="text" class="form-control form-control-lg" id="logradouro"
                                        name="logradouro" placeholder="Rua, Avenida, etc." required>
                                    <div class="invalid-feedback">
                                        Por favor, informe o logradouro.
                                    </div>
                                </div>

                                <!-- Cidade e Estado -->
                                <div class="col-md-8">
                                    <label for="cidade" class="form-label fw-semibold">
                                        <i class="bi bi-building me-2 text-success"></i>Cidade *
                                    </label>
                                    <input type="text" class="form-control form-control-lg" id="cidade" name="cidade"
                                        required>
                                    <div class="invalid-feedback">
                                        Por favor, informe a cidade.
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <label for="estado" class="form-label fw-semibold">
                                        <i class="bi bi-map me-2 text-success"></i>Estado *
                                    </label>
                                    <select class="form-select form-select-lg" id="estado" name="estado" required>
                                        <option value="">Selecione</option>
                                        <option value="AC">Acre</option>
                                        <option value="AL">Alagoas</option>
                                        <option value="AP">Amapá</option>
                                        <option value="AM">Amazonas</option>
                                        <option value="BA">Bahia</option>
                                        <option value="CE">Ceará</option>
                                        <option value="DF">Distrito Federal</option>
                                        <option value="ES">Espírito Santo</option>
                                        <option value="GO">Goiás</option>
                                        <option value="MA">Maranhão</option>
                                        <option value="MT">Mato Grosso</option>
                                        <option value="MS">Mato Grosso do Sul</option>
                                        <option value="MG">Minas Gerais</option>
                                        <option value="PA">Pará</option>
                                        <option value="PB">Paraíba</option>
                                        <option value="PR">Paraná</option>
                                        <option value="PE">Pernambuco</option>
                                        <option value="PI">Piauí</option>
                                        <option value="RJ">Rio de Janeiro</option>
                                        <option value="RN">Rio Grande do Norte</option>
                                        <option value="RS">Rio Grande do Sul</option>
                                        <option value="RO">Rondônia</option>
                                        <option value="RR">Roraima</option>
                                        <option value="SC">Santa Catarina</option>
                                        <option value="SP">São Paulo</option>
                                        <option value="SE">Sergipe</option>
                                        <option value="TO">Tocantins</option>
                                    </select>
                                    <div class="invalid-feedback">
                                        Por favor, selecione o estado.
                                    </div>
                                </div>

                                <!-- Ano de Fundação -->
                                <div class="col-md-6">
                                    <label for="anoFundacao" class="form-label fw-semibold">
                                        <i class="bi bi-calendar-event me-2 text-success"></i>Ano de Fundação *
                                    </label>
                                    <input type="number" class="form-control form-control-lg" id="anoFundacao"
                                        name="anoFundacao" min="1900" max="2024" required>
                                    <div class="invalid-feedback">
                                        Por favor, informe um ano válido (1900-2024).
                                    </div>
                                </div>

                                <!-- Nome do Comandante -->
                                <div class="col-md-6">
                                    <label for="nomeComandante" class="form-label fw-semibold">
                                        <i class="bi bi-person-badge me-2 text-success"></i>Nome do Atual Comandante *
                                    </label>
                                    <input type="text" class="form-control form-control-lg" id="nomeComandante"
                                        name="nomeComandante" required>
                                    <div class="invalid-feedback">
                                        Por favor, informe o nome do comandante.
                                    </div>
                                </div>

                                <!-- Buttons -->
                                <div class="col-12 mt-5">
                                    <div class="d-grid gap-3 d-md-flex justify-content-md-center">
                                        <button type="submit" class="btn btn-success btn-lg px-5 py-3 fw-semibold">
                                            <i class="bi bi-check-circle me-2"></i>Cadastrar Equipe
                                        </button>
                                        <a href="<?= BASE_URL ?>/inicio"
                                            class="btn btn-outline-secondary btn-lg px-5 py-3 fw-semibold">
                                            <i class="bi bi-arrow-left me-2"></i>Cancelar
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Success Modal -->
    <div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <!-- <h5 class="modal-title" id="successModalLabel">
                       Equipe Cadastrada!
                    </h5> -->
                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body text-center">
                    <div class="mb-3">
                        <i class="bi bi-trophy-fill text-success" style="font-size: 3rem;"></i>
                    </div>
                    <h5>Parabéns!</h5>
                    <p class="text-muted mb-0">
                        Sua equipe foi cadastrada com sucesso na plataforma FutPlay.
                        Agora você pode começar a adicionar confrontos!
                    </p>
                </div>
                <div class="modal-footer justify-content-center">
                    <div class="col-md-12 w-100">
                        <a role="button" href="<?= BASE_URL ?>/inicio" class="btn btn-success btn-lg btn-block w-100">
                            <i class="bi bi-house-fill me-2"></i>Voltar ao Início
                        </a>
                    </div>
                    <div class="col-md-12 mt-2 w-100">
                        <button type="button" class="btn btn-outline-secondary btn-lg btn-block w-100" data-bs-dismiss="modal">
                            Cadastrar Outra Equipe
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Dnager Modal -->
    <div class="modal fade" id="dangerModal" tabindex="-1" aria-labelledby="dangerModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <!-- <h5 class="modal-title" id="successModalLabel">
                       Equipe Cadastrada!
                    </h5> -->
                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body text-center">
                    <div class="mb-3">
                        <i class="bi bi-exclamation-triangle" style="font-size: 3rem;"></i>
                        <!-- <i class="bi bi-trophy-fill text-danger" style="font-size: 3rem;"></i> -->
                    </div>
                    <h5>Erro!</h5>
                    <p class="text-muted mb-0">
                        Ocorreu um erro ao tentar cadastrar a equipe. Por favor, tente novamente.
                    </p>
                </div>
                <div class="modal-footer justify-content-center">
                    <div class="col-md-12 w-100">
                        <a role="button" href="<?= BASE_URL ?>/inicio" class="btn btn-danger btn-lg btn-block w-100">
                            <i class="bi bi-house-fill me-2"></i>Voltar ao Início
                        </a>
                    </div>
                    <div class="col-md-12 mt-2 w-100">
                        <button type="button" class="btn btn-outline-secondary btn-lg btn-block w-100" data-bs-dismiss="modal">
                            Tentar novamente
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer-bg text-white py-5 mt-5">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-4">
                    <h5 class="fw-bold mb-3">
                        <i class="bi bi-trophy-fill me-2"></i>FutPlay
                    </h5>
                    <p class="text-light">
                        A plataforma completa para gerenciar equipes de futebol amador e seus confrontos. Simples,
                        rápido e eficiente.
                    </p>
                </div>

                <div class="col-lg-4">
                    <h5 class="fw-bold mb-3">Links Rápidos</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2">
                            <a href="<?= BASE_URL ?>/nova-equipe" class="text-light text-decoration-none">
                                <i class="bi bi-people-fill me-2"></i>Cadastrar Equipe
                            </a>
                        </li>
                        <li class="mb-2">
                            <a href="<?= BASE_URL ?>/novo-confronto" class="text-light text-decoration-none">
                                <i class="bi bi-calendar-event me-2"></i>Adicionar Confronto
                            </a>
                        </li>
                        <li class="mb-2">
                            <a href="<?= BASE_URL ?>/inicio#como-funciona" class="text-light text-decoration-none">
                                <i class="bi bi-info-circle me-2"></i>Como Funciona
                            </a>
                        </li>
                    </ul>
                </div>

                <div class="col-lg-4">
                    <h5 class="fw-bold mb-3">Contato</h5>
                    <div class="mb-3">
                        <p class="text-light mb-2">
                            <i class="bi bi-envelope-fill me-2"></i>contato@futplay.com.br
                        </p>
                        <p class="text-light mb-2">
                            <i class="bi bi-telephone-fill me-2"></i>(11) 99999-9999
                        </p>
                    </div>

                    <h6 class="fw-semibold mb-3">Redes Sociais</h6>
                    <div class="d-flex gap-3">
                        <a href="#" class="text-light fs-4" title="Facebook">
                            <i class="bi bi-facebook"></i>
                        </a>
                        <a href="#" class="text-light fs-4" title="Instagram">
                            <i class="bi bi-instagram"></i>
                        </a>
                        <a href="#" class="text-light fs-4" title="Twitter">
                            <i class="bi bi-twitter"></i>
                        </a>
                        <a href="#" class="text-light fs-4" title="WhatsApp">
                            <i class="bi bi-whatsapp"></i>
                        </a>
                    </div>
                </div>
            </div>

            <hr class="my-4 border-secondary">

            <div class="row">
                <div class="col-12 text-center">
                    <p class="text-light mb-0">
                        &copy; 2024 FutPlay. Todos os direitos reservados.
                    </p>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap 5.3 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Custom JS -->
    <script>
        const url = "<?= BASE_URL ?>";
    </script>
    <script src="<?= BASE_URL ?>/public/assets/js/script.js"></script>
    <script src="<?= BASE_URL ?>/public/assets/js/cadastro.js"></script>
</body>

</html>